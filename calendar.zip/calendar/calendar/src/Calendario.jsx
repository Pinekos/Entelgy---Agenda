import React from 'react'
import {LoginPage} from './pages/LoginPage'
import './styles.css'


export const Calendario = () => {
  return (

    <body>
        <LoginPage/>
    </body>
    
  )
}
